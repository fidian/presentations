﻿GL-DancingMen: 8-bit single-byte coded graphic character sets

(C)2007-2009 Das Ende der Wildnis (http://heiden.daynight.jp/)
(C)2008-2011 Gutenberg Labo (http://gutenberg.sourceforge.jp/), All rights reserved.

- GL-DancingMen License
  These fonts are free softwares.
  Unlimited permission is granted to use, copy, and distribute it, with or without modification, either commercially and noncommercially.
  THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.

- About GL-DancingMen font
　GL-DancingMen is based on the Cipher from "The Adventure of the Dancing Men", The Return of Sherlock Holmes by Arthur Conan Doyle.
　This font is redesign of ARANO-DancingMen.

　The Font includes only "A" to "Z", "a" to "z" and numerals.
　Alphabet "F", "J", "K", "Q", "U", "W", "X", "Z" and numerals are designed by Eunice (Das Ende der Wildnis).

--------
ARANO-DancingMen
(C)2007-2009 Das Ende der Wildnis (http://heiden.daynight.jp/), All rights reserved.

- ARANO-DancingMen license（2009/08/21 Reversion）
  These fonts are free softwares.
  Unlimited permission is granted to use, copy, and distribute it, with or without modification, either commercially and noncommercially.
  THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.
